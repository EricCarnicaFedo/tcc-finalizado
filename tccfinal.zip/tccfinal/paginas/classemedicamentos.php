<?php
class Medicamento
{
    private $idPrescricao;
    private $pet_id; // Alterando de nomeAnimal para pet_id
    private $tutor_id; // Adicionando tutor_id
    private $medicamento;
    private $dataPrescricao;
    private $dosagem;
    private $status; // Adicionando status

    // Métodos setters
    public function setIdPrescricao($valor) {
        $this->idPrescricao = $valor;
    }

    public function setPetId($valor) {
        $this->pet_id = $valor;
    }

    public function setTutorId($valor) {
        $this->tutor_id = $valor;
    }

    public function setMedicamento($valor) {
        $this->medicamento = $valor;
    }

    public function setDataPrescricao($valor) {
        $this->dataPrescricao = $valor;
    }

    public function setDosagem($valor) {
        $this->dosagem = $valor;
    }

    public function setStatus($valor) {
        $this->status = $valor;
    }

    // Métodos getters
    public function getIdPrescricao() {
        return $this->idPrescricao;
    }

    public function getPetId() {
        return $this->pet_id;
    }

    public function getTutorId() {
        return $this->tutor_id;
    }

    public function getMedicamento() {
        return $this->medicamento;
    }

    public function getDataPrescricao() {
        return $this->dataPrescricao;
    }

    public function getDosagem() {
        return $this->dosagem;
    }

    public function getStatus() {
        return $this->status;
    }

    // Listar todos os medicamentos prescritos
    public function listar() {
        require("conexaobd.php");

        $consulta = "SELECT * FROM medicamentos_prescritos ORDER BY dataPrescricao";
        $resultado = $pdo->prepare($consulta);
        $resultado->execute();

        return $resultado->fetchAll(PDO::FETCH_ASSOC);
    }

    // Consultar um medicamento específico
    public function consultar($idPrescricao) {
        require("conexaobd.php");

        $comando = "SELECT * FROM medicamentos_prescritos WHERE idPrescricao = :idPrescricao";
        $resultado = $pdo->prepare($comando);
        $resultado->bindParam(":idPrescricao", $idPrescricao);
        $resultado->execute();

        if ($resultado->rowCount() == 1) {
            $registro = $resultado->fetch(PDO::FETCH_ASSOC);
            $this->idPrescricao = $registro["idPrescricao"];
            $this->pet_id = $registro["pet_id"];
            $this->tutor_id = $registro["tutor_id"];
            $this->medicamento = $registro["medicamento"];
            $this->dataPrescricao = $registro["dataPrescricao"];
            $this->dosagem = $registro["dosagem"];
            $this->status = $registro["status"];
            return true;
        }
        return false;
    }

    // Inserir um novo medicamento prescrito
    public function inserir($pet_id, $tutor_id, $medicamento, $dataPrescricao, $dosagem, $status) {
        require("conexaobd.php");

        $comando = "INSERT INTO medicamentos_prescritos (pet_id, tutor_id, medicamento, dataPrescricao, dosagem, status) 
                    VALUES (:pet_id, :tutor_id, :medicamento, :dataPrescricao, :dosagem, :status)";
        $resultado = $pdo->prepare($comando);
        $resultado->bindParam(':pet_id', $pet_id);
        $resultado->bindParam(':tutor_id', $tutor_id);
        $resultado->bindParam(':medicamento', $medicamento);
        $resultado->bindParam(':dataPrescricao', $dataPrescricao);
        $resultado->bindParam(':dosagem', $dosagem);
        $resultado->bindParam(':status', $status);
        $resultado->execute();

        return ($resultado->rowCount() == 1) ? true : false;
    }

    // Alterar um medicamento prescrito existente
    public function alterar($idPrescricao, $pet_id, $tutor_id, $medicamento, $dataPrescricao, $dosagem, $status) {
        require("conexaobd.php");

        $comando = "UPDATE medicamentos_prescritos 
                    SET pet_id = :pet_id, tutor_id = :tutor_id, medicamento = :medicamento, 
                        dataPrescricao = :dataPrescricao, dosagem = :dosagem, status = :status 
                    WHERE idPrescricao = :idPrescricao";
        $resultado = $pdo->prepare($comando);
        $resultado->bindParam(':idPrescricao', $idPrescricao);
        $resultado->bindParam(':pet_id', $pet_id);
        $resultado->bindParam(':tutor_id', $tutor_id);
        $resultado->bindParam(':medicamento', $medicamento);
        $resultado->bindParam(':dataPrescricao', $dataPrescricao);
        $resultado->bindParam(':dosagem', $dosagem);
        $resultado->bindParam(':status', $status);
        $resultado->execute();

        return ($resultado->rowCount() == 1) ? true : false;
    }

    // Excluir um medicamento prescrito
    public function excluir($idPrescricao) {
        require("conexaobd.php");

        $comando = "DELETE FROM medicamentos_prescritos WHERE idPrescricao = :idPrescricao";
        $resultado = $pdo->prepare($comando);
        $resultado->bindParam(':idPrescricao', $idPrescricao);
        $resultado->execute();

        return ($resultado->rowCount() == 1) ? true : false;
    }
}
