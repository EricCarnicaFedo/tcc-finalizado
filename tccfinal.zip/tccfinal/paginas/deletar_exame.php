<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificando se o ID do exame foi fornecido
if (isset($_GET['id'])) {
    $exameId = $_GET['id'];

    // Preparando a consulta para excluir o exame
    $sql = "DELETE FROM exames_realizados WHERE idExame = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $exameId);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Exame excluído com sucesso!";
    } else {
        $_SESSION['message'] = "Erro ao excluir exame: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    // Redirecionando para a página de exames
    header("Location: pets.php");
    exit();
} else {
    $_SESSION['message'] = "ID do exame não fornecido!";
    header("Location: listaexames.php");
    exit();
}
?>
