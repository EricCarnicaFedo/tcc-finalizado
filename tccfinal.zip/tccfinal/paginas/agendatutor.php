<?php
include('conexaobd.php');

// Inicia a sessão, se ainda não foi iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Verifica se o tutor está logado
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] != 'tutor') {
    // Redireciona para o login se o tutor não estiver logado
    header("Location: login.php");
    exit();
}

try {
    // Garante que a conexão já está definida
    if (!isset($conn)) {
        $conn = new PDO('mysql:host=localhost;dbname=tccdois', 'root', ''); // Ajuste conforme suas credenciais
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    // Busca o ID do tutor na tabela 'usuarios' com base no ID do usuário na sessão
    $sql_usuario = "SELECT id, nome FROM usuarios WHERE id = :usuario_id AND tipo = 'tutor'";
    $stmt_usuario = $conn->prepare($sql_usuario);
    $stmt_usuario->bindParam(':usuario_id', $_SESSION['usuario_id'], PDO::PARAM_INT);
    $stmt_usuario->execute();

    $usuario = $stmt_usuario->fetch(PDO::FETCH_ASSOC);

    // Verifica se o tutor foi encontrado
    if ($usuario) {
        $usuario_id = $usuario['id'];
        $nome_tutor = $usuario['nome']; // Agora o nome é recuperado diretamente do banco de dados

        // Agora, buscamos o ID do tutor na tabela 'tutores' com base no ID do usuário
        $sql_tutor = "SELECT id FROM tutores WHERE nome = :nome_tutor AND clinica_id = (SELECT clinica_id FROM usuarios WHERE id = :usuario_id)";
        $stmt_tutor = $conn->prepare($sql_tutor);
        $stmt_tutor->bindParam(':nome_tutor', $nome_tutor, PDO::PARAM_STR);
        $stmt_tutor->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
        $stmt_tutor->execute();

        $tutor = $stmt_tutor->fetch(PDO::FETCH_ASSOC);

        if ($tutor) {
            $tutor_id = $tutor['id'];

            // Busca as consultas agendadas para o tutor
            $sql_consultas = "SELECT 
                                consultas_tutores.data_consulta,
                                consultas_tutores.hora_consulta,
                                consultas_tutores.descricao
                              FROM consultas_tutores
                              WHERE consultas_tutores.tutor_id = :tutor_id";
            $stmt_consultas = $conn->prepare($sql_consultas);
            $stmt_consultas->bindParam(':tutor_id', $tutor_id, PDO::PARAM_INT);
            $stmt_consultas->execute();

            $consultas = $stmt_consultas->fetchAll(PDO::FETCH_ASSOC);

            if (count($consultas) == 0) {
                // Não exibe nada se não houver consultas
            } else {
                // Exibe as consultas agendadas (pode ser formatado como necessário)
                foreach ($consultas as $consulta) {
                    // Processar cada consulta sem exibir diretamente
                    // Pode-se fazer algo com essas informações, como armazená-las em uma variável ou outro tipo de processamento
                }
            }
        } else {
            // Tutor não encontrado na tabela 'tutores', não exibe mensagem
        }
    } else {
        // Tutor não encontrado na tabela 'usuarios', não exibe mensagem
    }
} catch (PDOException $e) {
    // Não exibe a mensagem de erro na página
    // Pode-se logar o erro em um arquivo de log se necessário
    // file_put_contents('error_log.txt', $e->getMessage(), FILE_APPEND);
}
?>






<html lang="pt-br">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <!----======== CSS ======== -->
  <link rel="stylesheet" href="inicio.css">
  <link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="agenda.css">
<link rel="stylesheet" href="editar.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <!---------========= fontes =========------->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <script src="https://cdn.tailwindcss.com"></script>


<script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap">
  <!----===== Boxicons CSS ===== -->

  <script src="https://cdn.tailwindcss.com"></script>
  <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
  <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

  <!--<title>Dashboard Sidebar Menu</title>-->
</head>


<header id="navbar" class="flex justify-between items-center text-white p-4">
    <nav>
        <div class="titulonavbar">
            <i class="bx bxs-animal-paw"></i>
            <span class="text">Agenda</span>
        </div>
        <ul class="navbarconteudo">
            <!-- Manter apenas os itens desejados -->
        </ul>
    </nav>

    <div class="flex items-center space-x-4">
        <!-- Verifica se o nome do usuário está na sessão -->
        <span class="hidden md:inline-block">Bem-vindo, <?php echo isset($_SESSION['nome_usuario']) ? $_SESSION['nome_usuario'] : 'Usuário'; ?></span>

        <a href="logout.php" class="hover:underline">Sair</a>
        <i class="bx bx-bell"></i>
        <img src="https://placehold.co/30x30" alt="User avatar" class="w-8 h-8 rounded-full">
    </div>

    <i class='bx bx-menu menu-button' id="menu-button" style="font-size: 30px;"></i>
    <i class='bx bx-cog customize-button' id="customize-button" style="font-size: 20px;"></i>
    <div id="color-picker">
        <label for="navbar-color">Choose navbar color:</label>
        <input type="color" id="navbar-color" name="navbar-color" value="#4CAF50">
    </div>
</header>



  <div id="sidebar" class="sidebar">
    <div class="sidebar-header">
      <i class='bx bx-home-alt' style="font-size: 40px; color: white;  "></i>
      <h2>VetEtec</h2>
      <!-- Ícone de exemplo -->
    </div>
    <a href="javascript:void(0)" class="closebtn" id="close-sidebar"> <i class='bx bxs-chevron-right'></i></a>
    
    <a href="<?php echo ($_SESSION['tipo'] == 'veterinario') ? 'veterinario.php' : 'tutor.php'; ?>">
    <i class="bx bx-home"></i><span class="sidebar-text">Início</span>
</a>


    
  <a href="agenda.php"><i class='bx bx-calendar'></i> <span class="sidebar-text">Agenda</span></a>
  <a href="petstutor.php"><i class='bx bxs-cat'></i> <span class="sidebar-text">Pets</span></a>
  <a href="logout.php" style="margin-top: 100px;">
  <i class='bx bx-log-out'></i> <span class="sidebar-text">Sair</span>
</a>
    <a href="#"><i class='bx bx-moon theme-toggle' id="theme-toggle"></i> <span class="sidebar-text  tema   ">Tema</span></a>

  </div>
 
  <main class="p-6">
    <div class="bg-white p-6 rounded shadow-md">
        <div class="flex items-center space-x-4 mb-6">
            <button class="bg-gray-300 text-gray-700 px-4 py-2 rounded flex items-center">
                <i class="fas fa-arrow-left mr-2"></i> VOLTAR
            </button>
            <h1 class="text-xl font-bold">Minhas Consultas</h1>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white">
                <thead>
                    <tr>
                        <th class="py-2 px-4 border-b">Nome do Animal</th>
                        <th class="py-2 px-4 border-b">Data</th>
                        <th class="py-2 px-4 border-b">Hora</th>
                        <th class="py-2 px-4 border-b">Descrição</th>
                        <th class="py-2 px-4 border-b">Status</th>
                        <th class="py-2 px-4 border-b">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    require("conexaobd.php");

                    // Verificar se o tutor está logado
                    if (!isset($_SESSION['tutor_id'])) {
                        echo "<tr><td colspan='6' class='text-center text-red-500'>Erro: Você não está logado como tutor.</td></tr>";
                        exit();
                    }

                    $tutorId = $_SESSION['tutor_id'];

                    // Obter consultas marcadas pelo tutor logado
                    $query = "SELECT nome_animal, data_consulta, hora_consulta, descricao, status, idConsulta 
                              FROM consultas_marcadas WHERE tutor_id = ?";
                    $stmt = $pdo->prepare($query);
                    $stmt->bindParam(1, $tutorId, PDO::PARAM_INT);
                    $stmt->execute();
                    $consultas = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    // Caso não haja consultas
                    if (empty($consultas)) {
                        echo "<tr><td colspan='6' class='text-center'>Nenhuma consulta encontrada para este tutor.</td></tr>";
                    } else {
                        // Listar consultas
                        foreach ($consultas as $consulta) {
                            // Define a cor com base no status
                            switch ($consulta['status']) {
                                case 'Agendada':
                                    $statusColor = 'bg-yellow-500'; // Amarelo
                                    break;
                                case 'Realizada':
                                    $statusColor = 'bg-green-500'; // Verde
                                    break;
                                case 'Cancelada':
                                    $statusColor = 'bg-red-500'; // Vermelho
                                    break;
                                default:
                                    $statusColor = 'bg-gray-500'; // Cor padrão
                            }
                            ?>
                            <tr>
                                <td class="py-2 px-4 text-center"><?php echo htmlspecialchars($consulta['nome_animal']); ?></td>
                                <td class="py-2 px-4 text-center"><?php echo htmlspecialchars($consulta['data_consulta']); ?></td>
                                <td class="py-2 px-4 text-center"><?php echo htmlspecialchars($consulta['hora_consulta']); ?></td>
                                <td class="py-2 px-4 text-center"><?php echo htmlspecialchars($consulta['descricao']); ?></td>
                                <td class="py-2 px-4 text-center">
                                    <span class="text-white px-2 py-1 rounded <?php echo $statusColor; ?>">
                                        <?php echo htmlspecialchars($consulta['status']); ?>
                                    </span>
                                </td>
                                <td class="py-2 px-4 text-center">
                                    <?php if ($consulta['status'] != 'Cancelada' && $consulta['status'] != 'Realizada') : ?>
                                        <button onclick="cancelarConsulta(<?php echo $consulta['idConsulta']; ?>)" 
                                            class="bg-red-500 text-white px-2 py-1 rounded flex items-center justify-center">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
    </div>
</main>

<!-- Popup para marcar uma nova consulta -->
<div id="novaConsultaPopup" class="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center hidden">
    <div class="bg-white p-6 rounded shadow-lg w-96">
        <h2 class="text-2xl font-bold mb-4">Marcar Nova Consulta</h2>
        <form id="novaConsultaForm">
            <!-- Select dos pets -->
            <label for="pet" class="block text-sm font-medium text-gray-700">Escolha um Pet</label>
            <select id="pet" name="pet" class="mt-1 block w-full p-2 border border-gray-300 rounded-md">
                <?php
                $petsQuery = "SELECT id, nome FROM pets WHERE tutor_id = ?";
                $petsStmt = $pdo->prepare($petsQuery);
                $petsStmt->bindParam(1, $tutorId, PDO::PARAM_INT);
                $petsStmt->execute();
                $pets = $petsStmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($pets as $pet) {
                    echo "<option value='" . $pet['id'] . "'>" . htmlspecialchars($pet['nome']) . "</option>";
                }
                ?>
            </select>
            <br>

             <!-- Data e Hora da Consulta -->
             <div class="input-group">
                <label for="data_hora_consulta">Data e Hora da Consulta:</label>
                <div class="input-with-icon">
                    <i class='bx bx-calendar'></i>
                    <select name="data_hora_consulta" required>
                        <option value="">Selecione Data e Hora</option>
                        <?php foreach ($disponibilidades as $disponibilidade): ?>
                            <option value="<?php echo $disponibilidade; ?>"><?php echo $disponibilidade; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <!-- Descrição -->
            <label for="descricao" class="block text-sm font-medium text-gray-700 mt-4">Descrição</label>
            <textarea id="descricao" name="descricao" class="mt-1 block w-full p-2 border border-gray-300 rounded-md" readonly>
Consulta de rotina
            </textarea>
            <br>

            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded mt-4">Agendar Consulta</button>
        </form>
        <button id="closePopup" class="bg-red-500 text-white px-4 py-2 rounded mt-4">Fechar</button>
    </div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<br>
<br>

<script>
// Script para abrir e fechar o popup
document.getElementById('novaConsultaBtn').addEventListener('click', function() {
    document.getElementById('novaConsultaPopup').classList.remove('hidden');
});

document.getElementById('closePopup').addEventListener('click', function() {
    document.getElementById('novaConsultaPopup').classList.add('hidden');
});
</script>


<script>
    function cancelarConsulta(idConsulta) {
        if (confirm('Tem certeza que deseja cancelar esta consulta?')) {
            // Envia requisição AJAX para cancelar a consulta
            fetch(cancelar_consulta.php?idConsulta=${idConsulta}, {
                method: 'POST',
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    location.reload(); // Recarrega a página para atualizar os dados
                } else {
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Erro ao cancelar consulta:', error);
                alert('Ocorreu um erro ao tentar cancelar a consulta.');
            });
        }
    }
</script>






    <footer class="footer">
      <div class="footer-content">
        <h2 class="footer-title">Gestão Veterinária</h2>
        <p class="footer-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at sapien eu justo ultrices feugiat at id quam. Vivamus eu tellus vel ex pretium hendrerit. Phasellus eget vehicula ex, sit amet dictum felis.</p>
        <ul class="footer-links">
          <li><a href="#">Início</a></li>
          <li><a href="#">Sobre</a></li>
          <li><a href="#">Serviços</a></li>
          <li><a href="#">Equipe</a></li>
          <li><a href="#">Contato</a></li>
        </ul>
        <div class="social-icons">
          <a href="#"><img src="https://img.icons8.com/ios-filled/50/ffffff/facebook-new.png" alt="Facebook"></a>
          <a href="#"><img src="https://img.icons8.com/ios-filled/50/ffffff/twitter.png" alt="Twitter"></a>
          <a href="#"><img src="https://img.icons8.com/ios-filled/50/ffffff/linkedin.png" alt="LinkedIn"></a>
          <a href="#"><img src="https://img.icons8.com/ios-filled/50/ffffff/instagram-new.png" alt="Instagram"></a>
        </div>
        <div class="contact-info">
          <div class="contact-info-item">
            <img src="https://img.icons8.com/material-rounded/24/ffffff/phone--v1.png" alt="Telefone">
            +1 234 567 890
          </div>
          <div class="contact-info-item">
            <img src="https://img.icons8.com/material-rounded/24/ffffff/email-open--v1.png" alt="E-mail">
            exemplo@exemplo.com
          </div>
        </div>
        <div class="subscribe">
          <input type="email" class="subscribe-input" placeholder="Digite seu e-mail">
          <button class="subscribe-button">Assinar</button>
        </div>
        <div class="company-info">
          <h3>Sobre Nós</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at sapien eu justo ultrices feugiat at id quam. Vivamus eu tellus vel ex pretium hendrerit. Phasellus eget vehicula ex, sit amet dictum felis.</p>
        </div>
        <div class="quick-links">
          <h3>Links Rápidos</h3>
          <ul>
            <li><a href="#">Política de Privacidade</a></li>
            <li><a href="#">Termos de Serviço</a></li>
            <li><a href="#">FAQ</a></li>
            <li><a href="#">Suporte</a></li>
          </ul>
        </div>
        <div class="about-section">
          <h3>Nossa Missão</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris at sapien eu justo ultrices feugiat at id quam. Vivamus eu tellus vel ex pretium hendrerit. Phasellus eget vehicula ex, sit amet dictum felis.</p>
        </div>
        <div class="animal-images">
          <img src="https://placeimg.com/100/100/animals" alt="Animal">
          <img src="https://placeimg.com/100/100/animals" alt="Animal">
          <img src="https://placeimg.com/100/100/animals" alt="Animal">
          <img src="https://placeimg.com/100/100/animals" alt="Animal">
        </div>
      </div>
    </footer>
    <script>
     const themeToggle = document.getElementById('theme-toggle');
      const customizeButton = document.getElementById('customize-button');
      const colorPicker = document.getElementById('color-picker');
      const navbar = document.getElementById('navbar');
      const body = document.body;
      const sidebar = document.getElementById('sidebar');
      const menuButton = document.getElementById('menu-button');
      const closeSidebar = document.getElementById('close-sidebar');
      let customNavbarColor = '#afd4c3'; // Cor padrão da barra de navegação e da barra lateral
      themeToggle.addEventListener('click', () => {
        body.classList.toggle('dark-theme');
        themeToggle.classList.toggle('bx-sun');
        // Restaurar a cor personalizada ao alternar entre temas claro e escuro
        if (body.classList.contains('dark-theme')) {
          navbar.style.backgroundColor = '#121212'; // Cor de fundo padrão do tema escuro
          sidebar.style.backgroundColor = '#121212'; // Cor de fundo padrão do tema escuro para a barra lateral
        } else {
          navbar.style.backgroundColor = customNavbarColor; // Restaurar a cor personalizada da barra de navegação
          sidebar.style.backgroundColor = customNavbarColor; // Restaurar a cor personalizada da barra lateral
        }
      });
      customizeButton.addEventListener('click', () => {
        colorPicker.style.display = colorPicker.style.display === 'block' ? 'none' : 'block';
      });
      document.getElementById('navbar-color').addEventListener('input', (event) => {
        customNavbarColor = event.target.value; // Armazenar a cor personalizada
        navbar.style.backgroundColor = customNavbarColor; // Atualizar a cor da barra de navegação
        sidebar.style.backgroundColor = customNavbarColor; // Atualizar a cor da barra lateral
      });
      menuButton.addEventListener('click', () => {
        sidebar.style.left = '0';
        navbar.style.transform = 'translateY(-100%)';
      });
      closeSidebar.addEventListener('click', () => {
        sidebar.style.left = '-250px';
        navbar.style.transform = 'translateY(0)';
      });
    document.getElementById('customize-button').addEventListener('click', function() {
      this.classList.toggle('rotated'); // Adiciona ou remove a classe 'rotated' ao clicar
  });
   document.addEventListener('DOMContentLoaded', function() {
      var conteudo = document.querySelector('.conteudo');
      setTimeout(function() {
        conteudo.classList.add('entrou');
      }, 500); // Ajuste o tempo conforme necessário
    });

// Mostrar o popup
document.getElementById('openPopup').addEventListener('click', function () {
        document.getElementById('popupContainer').style.display = 'flex';
    });

    // Fechar o popup
    document.getElementById('closePopup').addEventListener('click', function () {
        document.getElementById('popupContainer').style.display = 'none';
    });
    </script>

    
</body>
</html>