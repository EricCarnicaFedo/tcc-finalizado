<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificando se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tutorId = $_POST['tutor'];
    $petId = $_POST['pet'];
    $tipoExame = $_POST['tipoExame'];
    $dataExame = $_POST['dataExame'];
    $resultado = $_POST['resultado'];

    // Inserindo dados na tabela exames_realizados
    $sql = "INSERT INTO exames_realizados (tipoExame, dataExame, resultado, idPaciente) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $tipoExame, $dataExame, $resultado, $petId); // Atualizando a ordem dos parâmetros

    if ($stmt->execute()) {
        $_SESSION['message'] = "Exame adicionado com sucesso!";
    } else {
        $_SESSION['message'] = "Erro ao adicionar exame: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    header("Location: adicionarexames.php"); // Redireciona para a página de adicionar exame
    exit();
}
?>
