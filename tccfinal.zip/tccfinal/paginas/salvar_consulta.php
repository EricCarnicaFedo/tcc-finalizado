<?php 
session_start(); // Inicie a sessão
$message = ''; // Inicializa a variável

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Limpa a mensagem após exibição
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois"; // Banco de dados

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $proprietario = $_POST['proprietario'];
    $animal = $_POST['animal'];
    $data_hora_consulta = $_POST['data_hora_consulta'];
    $descricao = $_POST['descricao'];

    // Extrai a data e a hora separadas da string de data_hora_consulta
    list($data_consulta, $hora_consulta) = explode(' ', $data_hora_consulta);

    // Verificar se a consulta está disponível
    $query_check = "SELECT * FROM consultas_marcadas WHERE data_consulta = ? AND hora_consulta = ? AND status = 'Reservado'";
    $stmt_check = $conn->prepare($query_check);
    $stmt_check->bind_param("ss", $data_consulta, $hora_consulta);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        // Se já houver consulta agendada para esse horário
        $_SESSION['message'] = 'Este horário já está reservado. Por favor, selecione outro horário.';
        header('Location: adicionar_consulta.php');
        exit();
    }

    // Verificar se o tutor e o pet existem
    $query_tutor = "SELECT id FROM tutores WHERE id = ?";
    $stmt_tutor = $conn->prepare($query_tutor);
    $stmt_tutor->bind_param("i", $proprietario);
    $stmt_tutor->execute();
    $result_tutor = $stmt_tutor->get_result();

    if ($result_tutor->num_rows == 0) {
        $_SESSION['message'] = 'Tutor não encontrado.';
        header('Location: adicionar_consulta.php');
        exit();
    }

    $query_pet = "SELECT id FROM pets WHERE id = ?";
    $stmt_pet = $conn->prepare($query_pet);
    $stmt_pet->bind_param("i", $animal);
    $stmt_pet->execute();
    $result_pet = $stmt_pet->get_result();

    if ($result_pet->num_rows == 0) {
        $_SESSION['message'] = 'Animal não encontrado.';
        header('Location: adicionar_consulta.php');
        exit();
    }

    // Adicionar a consulta na tabela consultas_marcadas
    $query_insert = "INSERT INTO consultas_marcadas (nome_animal, data_consulta, hora_consulta, descricao, status, pet_id, tutor_id)
                     VALUES (?, ?, ?, ?, 'Reservado', ?, ?)";
    $stmt_insert = $conn->prepare($query_insert);
    $stmt_insert->bind_param("ssssii", $nome_animal, $data_consulta, $hora_consulta, $descricao, $animal, $proprietario);

    // Definindo o nome do animal
    $nome_animal_query = "SELECT nome FROM pets WHERE id = ?";
    $stmt_nome_animal = $conn->prepare($nome_animal_query);
    $stmt_nome_animal->bind_param("i", $animal);
    $stmt_nome_animal->execute();
    $result_nome_animal = $stmt_nome_animal->get_result();
    $row_nome_animal = $result_nome_animal->fetch_assoc();
    $nome_animal = $row_nome_animal['nome'];

    // Executar a inserção
    if ($stmt_insert->execute()) {
        // Atualiza o horário na tabela 'horarios' para 'Reservado'
        $query_update = "UPDATE horarios SET disponibilidade = 'Reservado' WHERE data = ? AND horario = ?";
        $stmt_update = $conn->prepare($query_update);
        $stmt_update->bind_param("ss", $data_consulta, $hora_consulta);
        $stmt_update->execute();

        $_SESSION['message'] = 'Consulta agendada com sucesso!';
    } else {
        $_SESSION['message'] = 'Erro ao agendar consulta.';
    }

    // Redireciona para a página de adicionar consulta
    header('Location: adicionarconsulta.php');
    exit();
}

// Fechar conexão
$conn->close();
?>
