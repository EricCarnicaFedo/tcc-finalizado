<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tccdois";

// Criando conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificando a conexão
if ($conn->connect_error) {
    error_log("Conexão falhou: " . $conn->connect_error);
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificando se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tutorId = $_POST['tutor']; // ID do tutor
    $petId = $_POST['pet_id']; // ID do pet
    $medicamento = $_POST['medicamento']; // Medicamento prescrito
    $dataPrescricao = $_POST['dataPrescricao']; // Data da prescrição
    $dosagem = $_POST['dosagem']; // Dosagem do medicamento
    $status = $_POST['status']; // Status do medicamento

    // Verificar se os dados obrigatórios estão presentes
    if (empty($tutorId) || empty($petId) || empty($medicamento) || empty($dataPrescricao) || empty($dosagem) || empty($status)) {
        $_SESSION['message'] = "Por favor, preencha todos os campos!";
        error_log("Campos obrigatórios não preenchidos.");
        header("Location: adicionar_medicamentos.php");
        exit();
    }

    // Verificando os dados recebidos
    error_log("Pet ID enviado pelo formulário: " . $petId);

    // Verificar se o pet_id existe no banco de dados
    $sqlPet = "SELECT id, tutor_id FROM pets WHERE id = ?";
    $stmtPet = $conn->prepare($sqlPet);
    $stmtPet->bind_param("i", $petId); // Bind do pet_id
    $stmtPet->execute();
    $resultPet = $stmtPet->get_result();

    if ($rowPet = $resultPet->fetch_assoc()) {
        $petId = $rowPet['id']; // Atualiza o pet_id com o ID do pet encontrado
        $tutorId = $rowPet['tutor_id']; // Atualiza o tutor_id com o ID do tutor
    } else {
        // Log de erro
        error_log("Pet não encontrado no banco de dados: " . $petId);
        $_SESSION['message'] = "Pet não encontrado!";
        header("Location: adicionar_medicamentos.php");
        exit();
    }

    // Inserindo dados na tabela de medicamentos prescritos
    $sql = "INSERT INTO medicamentos_prescritos (pet_id, tutor_id, medicamento, dataPrescricao, dosagem, status) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        error_log("Erro ao preparar a consulta SQL para inserir medicamento: " . $conn->error);
        $_SESSION['message'] = "Erro ao preparar consulta.";
        header("Location: adicionar_medicamentos.php");
        exit();
    }

    // Associando os parâmetros corretos
    $stmt->bind_param("iissss", $petId, $tutorId, $medicamento, $dataPrescricao, $dosagem, $status); // Associando os parâmetros

    if ($stmt->execute()) {
        $_SESSION['message'] = "Medicamento prescrito com sucesso!";
    } else {
        error_log("Erro ao executar a consulta SQL: " . $stmt->error);
        $_SESSION['message'] = "Erro ao adicionar medicamento: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    
    header("Location: adicionar_medicamentos.php");
    exit();
}

?>
