<?php
include('conexaobd.php');

// Inicia a sessão, se ainda não foi iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

try {
    // Garante que a conexão já está definida
    if (!isset($conn)) {
        $conn = new PDO('mysql:host=localhost;dbname=tccdois', 'root', ''); // Ajuste conforme suas credenciais
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    // Busca o ID do tutor na tabela 'usuarios' com base no ID do usuário na sessão
    $sql_usuario = "SELECT id, nome FROM usuarios WHERE id = :usuario_id AND tipo = 'tutor'";
    $stmt_usuario = $conn->prepare($sql_usuario);
    $stmt_usuario->bindParam(':usuario_id', $_SESSION['usuario_id'], PDO::PARAM_INT);
    $stmt_usuario->execute();

    $usuario = $stmt_usuario->fetch(PDO::FETCH_ASSOC);

    // Verifica se o tutor foi encontrado
    if ($usuario) {
        $usuario_id = $usuario['id'];
        $nome_tutor = $usuario['nome']; // Agora o nome é recuperado diretamente do banco de dados

        // Agora, buscamos o ID do tutor na tabela 'tutores' com base no ID do usuário
        $sql_tutor = "SELECT id FROM tutores WHERE nome = :nome_tutor AND clinica_id = (SELECT clinica_id FROM usuarios WHERE id = :usuario_id)";
        $stmt_tutor = $conn->prepare($sql_tutor);
        $stmt_tutor->bindParam(':nome_tutor', $nome_tutor, PDO::PARAM_STR);
        $stmt_tutor->bindParam(':usuario_id', $usuario_id, PDO::PARAM_INT);
        $stmt_tutor->execute();

        $tutor = $stmt_tutor->fetch(PDO::FETCH_ASSOC);

        if ($tutor) {
            $tutor_id = $tutor['id'];

            // Se o formulário de adicionar pet for submetido, processa a inserção
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $nome_pet = $_POST['nome_pet'];
                $raca_pet = $_POST['raca_pet'];
                $idade_pet = $_POST['idade_pet']; // Agora, em vez de data_nascimento, usaremos idade
                $especie_pet = $_POST['especie_pet']; // Novo campo para a espécie

                // Inserção de novo pet para o tutor
                $sql_pet = "INSERT INTO pets (nome, raca, idade, especie, tutor_id) VALUES (:nome_pet, :raca_pet, :idade_pet, :especie_pet, :tutor_id)";
                $stmt_pet = $conn->prepare($sql_pet);
                $stmt_pet->bindParam(':nome_pet', $nome_pet, PDO::PARAM_STR);
                $stmt_pet->bindParam(':raca_pet', $raca_pet, PDO::PARAM_STR);
                $stmt_pet->bindParam(':idade_pet', $idade_pet, PDO::PARAM_INT); // Alterado para idade
                $stmt_pet->bindParam(':especie_pet', $especie_pet, PDO::PARAM_STR); // Ligação com a espécie
                $stmt_pet->bindParam(':tutor_id', $tutor_id, PDO::PARAM_INT);
                $stmt_pet->execute();

                // Redireciona após adicionar o pet
                header("Location: petstutor.php");
                exit();
            }
        }
    }
} catch (PDOException $e) {
    echo "Erro ao adicionar pet: " . $e->getMessage();
}
?>

<style>
    /* Estilos principais para o formulário */
body {
    font-family: 'Arial', sans-serif;
    background-color: #f7f7f7;
    margin: 0;
    padding: 0;
}

.form-container {
    background: #fff;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    width: 50%;
    margin: 50px auto;
}

h2 {
    text-align: center;
    color: #4CAF50;
    margin-bottom: 20px;
}

label {
    font-size: 16px;
    color: #333;
    margin-bottom: 10px;
    display: block;
}

input[type="text"],
input[type="number"],
select {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 14px;
    background-color: #f9f9f9;
}

input[type="text"]:focus,
input[type="number"]:focus,
select:focus {
    border-color: #4CAF50;
    outline: none;
}

input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 15px 20px;
    font-size: 16px;
    width: 100%;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

/* Ajustando o layout responsivo */
@media (max-width: 768px) {
    .form-container {
        width: 80%;
    }
}

@media (max-width: 480px) {
    .form-container {
        width: 90%;
    }
}
</style>

<!-- Formulário para adicionar um novo pet -->
<form method="POST" action="adicionar_pet.php">
    <div class="form-container">
        <label for="nome_pet">Nome do Pet:</label>
        <input type="text" name="nome_pet" required><br>

        <label for="raca_pet">Raça do Pet:</label>
        <input type="text" name="raca_pet" required><br>

        <label for="idade_pet">Idade do Pet:</label>
        <input type="number" name="idade_pet" required><br>

        <label for="especie_pet">Espécie do Pet:</label>
        <input type="text" name="especie_pet" required><br>

        <label for="sexo_pet">Sexo do Pet:</label>
        <select name="sexo_pet" required>
            <option value="Macho">Macho</option>
            <option value="Fêmea">Fêmea</option>
        </select><br>

        <input type="submit" value="Adicionar Pet" class="btn-submit">
    </div>
</form>  
